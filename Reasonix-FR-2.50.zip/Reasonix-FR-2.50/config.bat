@echo off
rem ============================================================
rem  Reasonix Studio FR 2.50 - variables du paquet
rem  Seul fichier a modifier si l'installation ou le disque change.
rem ============================================================

rem Dossier d'installation de Reasonix Studio.
set "REASONIX_APP=J:\Reasonix Studio"

rem Dossier temporaire. Aucun fichier temporaire n'est ecrit sur C:.
set "REASONIX_TEMP=G:\Temp"

rem Python 3.13 (repli : python du PATH).
set "REASONIX_PY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not exist "%REASONIX_PY%" set "REASONIX_PY=python"

rem Node.js facultatif : vide = detection automatique
rem (node.exe du PATH, sinon l'Electron de Reasonix Studio).
set "REASONIX_NODE="

rem Version du paquet.
set "REASONIX_VERSION=2.50"
