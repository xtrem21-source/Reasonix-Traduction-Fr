"""Adapte patch249.py a la build 2.50 (noms de variables renommes par le minifieur).

En 2.50 : b = langue courante, x = dictionnaire courant, y = recueil des dictionnaires.
En 2.49 : y = langue, b = dictionnaire, v = recueil.
"""
import io, re

CIBLE = r"J:\Reasonix\dev\Reasonix-FR-2.50\tools\patch249.py"
BT = '`'

BLOC = """def patches():
    return [
        ('R1_traduire',
         'function k(e,t){let n=x[e]??e;',
         'function k(e,t){let n=(b===%sfr%s?globalThis.__FR?.[e]:void 0)??x[e]??e;' % (BT, BT)),
        ('R2_resolve',
         'return t===%szh%s||t===%sen%s?t:T()' % (BT, BT, BT, BT),
         'return t===%szh%s||t===%sen%s||t===%sfr%s?t:T()' % (BT, BT, BT, BT, BT, BT)),
        ('R3_lang',
         'document.documentElement.lang=b===%szh%s?%szh-CN%s:%sen%s' % (BT, BT, BT, BT, BT, BT),
         'document.documentElement.lang=b===%szh%s?%szh-CN%s:b===%sfr%s?%sfr%s:%sen%s' % (BT, BT, BT, BT, BT, BT, BT, BT, BT, BT)),
        ('R4_dict',
         'x=y[b]',
         'x=y[b]??globalThis.__FR??y.en'),
        ('R6_machine',
         'function T(){return E(navigator.languages?.[0]??navigator.language??%s%s)?%szh%s:%sen%s}' % (BT, BT, BT, BT, BT, BT),
         'function T(){let L=navigator.languages?.[0]??navigator.language??%s%s;return E(L)?%szh%s:(L.toLowerCase().startsWith(%sfr%s)?%sfr%s:%sen%s)}' % (BT, BT, BT, BT, BT, BT, BT, BT, BT, BT)),
    ]
"""

src = io.open(CIBLE, encoding="utf-8").read()

# 1. remplacer tout le bloc patches()
nouveau, n = re.subn(r"(?s)def patches\(\):.*?\n    \]", lambda m: BLOC.rstrip("\n"), src, count=1)
if n != 1:
    raise SystemExit("bloc patches() introuvable (%d)" % n)
src = nouveau

# 2. le recueil des dictionnaires s'appelle y en 2.50, plus v
avant = src.count(";v.fr=")
src = src.replace(";v.fr=", ";y.fr=")

# 3. la variable de langue du patch R1 s'appelle b en 2.50 (plus y)
io.open(CIBLE, "w", encoding="utf-8", newline="\n").write(src)
print("bloc patches() reecrit")
print("remplacements v.fr -> y.fr :", avant)
print("taille finale :", len(src), "octets")
