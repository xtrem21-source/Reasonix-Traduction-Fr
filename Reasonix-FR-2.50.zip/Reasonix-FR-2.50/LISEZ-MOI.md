# Francisation Reasonix Studio 2.49

> Patch de l'application installée dans **`J:\Reasonix Studio`**. Réversible : chaque fichier modifié est sauvegardé dans `backups\`.
> Aucun fichier temporaire n'est écrit sur `C:` : tout passe par **`G:\Temp`**.

## Ce que fait ce paquet

| Étape | Contenu |
|---|---|
| Interface (`frontend-next`) | dictionnaire FR de **5 034 entrées**, injecté dans le bundle i18n réellement chargé ; le sélecteur de langue reçoit **Français** |
| Chaînes natives (`app.asar`) | page de démarrage, menu contextuel, menu du tray, dialogues de plantage, dialogue d'ancienne version |
| Écran de démarrage HTML | reconnaît `fr` au lieu de retomber sur l'anglais |

Le paquet **détecte** les fichiers à patcher au lieu de coder leurs noms en dur : il lit `index.html` pour trouver le bundle i18n courant, puis choisit le bundle `Settings-*.js` que le bundle principal charge réellement. C'est ce qui permet de le rejouer après une mise à jour.

La version 2.49 apporte **63 nouvelles chaînes** traduites dans `dict/parts/batch_0001.json` : descriptions des outils intégrés (outils d'arrière-plan, navigateur, plan, mémoire, MCP), textes du budget horaire et du proxy, autorisations par source et par application, et l'explication du bail d'écriture. Les 4 971 entrées de la 2.48 sont réutilisées telles quelles.

## État vérifié du build 2.49

| Élément | Valeur constatée |
|---|---|
| Version | 2.49.0 (`Reasonix Studio.exe`, `app.asar`) |
| Bundle i18n chargé | `assets\i18n-BR2QJ_aY.js` |
| Bundle principal | `assets\index-CLYpAehB.js` |
| Bundle Settings chargé | `assets\Settings-Bbgyi4OO.js` |
| Motifs du patch | 6/6 sur le bundle i18n, sélecteur de langue présent, motif d'`index.html` présent |
| Motifs natifs | 11 remplacements sur 8 fichiers, 4/4 marqueurs après reconstruction |

Contrôle rejouable sans rien écrire :

```text
py tools\patch249.py --dry-run
py tools\patch_asar249.py --dry-run
```

## Variables

Tout est centralisé dans **`config.bat`** :

| Variable | Valeur par défaut | Rôle |
|---|---|---|
| `REASONIX_APP` | `J:\Reasonix Studio` | dossier d'installation de Studio |
| `REASONIX_TEMP` | `G:\Temp` | dossier temporaire (jamais `C:`) |
| `REASONIX_PY` | Python 3.13, sinon `python` | interpréteur |
| `REASONIX_NODE` | vide | Node.js facultatif ; sinon l'Electron de Studio sert de Node |

Modifie uniquement ce fichier si l'installation change de disque.

## Utilisation

```text
1. Fermer complètement Reasonix Studio
   (icône de la zone de notification → Quitter)
2. Double-cliquer Francisation_2.49.bat
3. Rouvrir Reasonix Studio
4. Paramètres → Apparence → Langue → Français
```

En cas d'échec, le `.bat` s'arrête et affiche la raison. Le patch natif vérifie la syntaxe des 8 fichiers et le paquet reconstruit **avant** de remplacer `app.asar` : il ne s'installe jamais à moitié.

## Ce qui est traduit

- Toute l'interface : menus, sous-menus, réglages, infobulles, messages d'erreur, pages de la 2.47 à la 2.49 (exécutions planifiées, bac à sable, texte externe, aperçus de fichiers, gestion des modules, budget horaire, proxy, autorisations).
- Les descriptions des outils intégrés affichées dans les réglages et les cartes d'appel.
- Les cinq skills ajoutés et leurs descriptions d'interface.
- Les chaînes natives : démarrage, menu contextuel, menu du tray, plantages, ancienne version.

## Ce qui ne l'est pas

| Élément | Pourquoi |
|---|---|
| Le noyau Go (CLI, TUI) | catalogue compilé dans le binaire, non modifiable sans reconstruire Go |
| Les notifications système | passent par le noyau, désactivées par défaut |
| Les réponses du modèle | elles suivent la langue de tes messages, pas ce réglage |
| Les mots-clés de recherche des réglages | 174 chaînes 2.49 vivent dans des tableaux `keywords:[…]` : jamais affichées, donc non traduites |

## Restauration

Les originaux sont dans `backups\`, nommés `<horodatage>__<type>__<fichier>`.
Recopie le fichier voulu à sa place :

| Sauvegarde | Destination |
|---|---|
| `*__i18n__i18n-*.js` | `…\resources\frontend-next\dist\assets\` |
| `*__settings__Settings-*.js` | idem |
| `*__index__index.html` | `…\resources\frontend-next\dist\` |
| `*__app.asar` | `…\resources\app.asar` |

Restauration automatique du dernier original de chaque fichier :

```text
py tools\patch249.py --restore
```

Les sauvegardes de la 2.48 sont conservées à part, dans `old\2026-10-23_archive-2.48\` : elles correspondent à des bundles qui ne sont plus chargés.

## Après une mise à jour de Reasonix

Les bundles changent de nom : relance simplement `Francisation_2.49.bat`. Le script retrouve les nouveaux fichiers et les patche. Si un motif a changé, il s'arrête en le disant — il ne patch jamais à moitié. Les chaînes ajoutées par la nouvelle version se traduisent en complétant `dict/parts/batch_NNNN.json` puis en relançant `py tools\merge249.py`.

## Contenu du paquet

```text
config.bat                  variables (installation, temporaire, python, node)
Francisation_2.49.bat       application en deux étapes
MENU-REASONIX.bat           menu unifié (français / micro / les deux)
tools\patch249.py           interface web (i18n, Settings, index.html)
tools\patch_asar249.py      chaînes natives d'app.asar
tools\merge249.py           fusion des lots de traduction
tools\translate249.py       maintenance : traduction des chaînes neuves (API DeepSeek)
tools\asar_patches.json     motifs natifs
dict\fr_dict_248.json       dictionnaire livré en 2.48 (4 971 entrées)
dict\fr_dict_249.json       dictionnaire courant (5 034 entrées)
dict\parts\batch_0001.json  les 63 chaînes 2.49
dict\en_dict_249.json       catalogue anglais extrait du build 2.49
backups\                    originaux des fichiers remplacés
old\                        archives 2.48 et brouillons écartés
Reasonix-Voice-Input-publish\  module micro (inchangé depuis la 2.48)
```
