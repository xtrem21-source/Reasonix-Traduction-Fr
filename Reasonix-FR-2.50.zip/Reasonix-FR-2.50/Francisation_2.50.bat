@echo off
setlocal EnableExtensions
title Francisation Reasonix %REASONIX_VERSION%
set "ROOT=%~dp0"
call "%ROOT%config.bat"

rem Tout le temporaire va sur G: (jamais dans %LOCALAPPDATA%\Temp).
if not exist "%REASONIX_TEMP%" mkdir "%REASONIX_TEMP%" >nul 2>&1
set "TMP=%REASONIX_TEMP%"
set "TEMP=%REASONIX_TEMP%"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONIOENCODING=utf-8"

echo ============================================
echo  Francisation Reasonix Studio %REASONIX_VERSION%
echo ============================================
echo  Installation : %REASONIX_APP%
echo  Temporaire   : %REASONIX_TEMP%
echo.

if not exist "%REASONIX_APP%\resources\frontend-next\dist\index.html" (
  echo ERREUR : Reasonix Studio est introuvable.
  echo Attendu : %REASONIX_APP%
  echo Modifie REASONIX_APP dans config.bat si le dossier a change.
  echo.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq Reasonix Studio.exe" /NH 2>nul | find /I "Reasonix Studio.exe" >nul
if not errorlevel 1 (
  echo Reasonix Studio est ouvert.
  echo Ferme-le completement ^(zone de notification : Quitter^), puis relance ce fichier.
  echo.
  pause
  exit /b 1
)

echo [1/2] Interface ^(frontend^)...
"%REASONIX_PY%" "%ROOT%tools\patch249.py"
if errorlevel 1 goto :err

echo.
echo [2/2] Chaines natives ^(app.asar^)...
"%REASONIX_PY%" "%ROOT%tools\patch_asar249.py"
if errorlevel 1 goto :err

echo.
echo TERMINE.
echo Relance Reasonix Studio, puis : Parametres ^> Apparence ^> Langue ^> Francais
echo.
pause
exit /b 0

:err
echo.
echo ECHEC. Lis le message ci-dessus.
echo Sauvegardes : %ROOT%backups
pause
exit /b 1
