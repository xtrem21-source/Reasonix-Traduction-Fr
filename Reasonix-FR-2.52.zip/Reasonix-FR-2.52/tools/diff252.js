/* Compare le catalogue 2.52 au dictionnaire FR 2.49.
   Sortie : dict\parts\a_traduire_252.json  {chinois: anglais} des cles sans FR
            dict\parts\obsoletes_252.json    cles FR qui ne sont plus dans le build
*/
const fs = require('fs');
const path = require('path');
const ROOT = path.dirname(__dirname);
const D = path.join(ROOT, 'dict');
const en = JSON.parse(fs.readFileSync(path.join(D, 'en_dict_252.json'), 'utf8'));
const fr = JSON.parse(fs.readFileSync(path.join(D, 'fr_dict_249.json'), 'utf8'));

const missing = {};
for (const k of Object.keys(en)) if (!(k in fr)) missing[k] = en[k];
const obsolete = {};
for (const k of Object.keys(fr)) if (!(k in en)) obsolete[k] = fr[k];

fs.writeFileSync(path.join(D, 'parts', 'a_traduire_252.json'), JSON.stringify(missing, null, 0), 'utf8');
fs.writeFileSync(path.join(D, 'parts', 'obsoletes_252.json'), JSON.stringify(obsolete, null, 0), 'utf8');

console.log('catalogue 2.52 :', Object.keys(en).length);
console.log('dictionnaire FR 2.49 :', Object.keys(fr).length);
console.log('a traduire :', Object.keys(missing).length);
console.log('obsoletes (inutilisees) :', Object.keys(obsolete).length);
console.log('couverture actuelle :', ((1 - Object.keys(missing).length / Object.keys(en).length) * 100).toFixed(2) + ' %');
