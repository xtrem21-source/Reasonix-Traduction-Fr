"""Patche les chaines NATIVES de Reasonix Studio 2.49 (app.asar).

Couvre : page de demarrage, menu contextuel, dialogues d'erreur, dialogue
ancienne version, menu du tray.

Usage :
  python patch_asar249.py --dry-run   # extrait et montre, ne reinstalle pas
  python patch_asar249.py             # applique (sauvegarde de app.asar)

Chemins : REASONIX_APP (defaut J:\\Reasonix Studio) et REASONIX_TEMP
(defaut G:\\Temp). Le module asar est embarque dans tools\\node_modules\\asar.
Node : node.exe du PATH, sinon l'Electron de Studio en mode Node.
"""
import os, sys, json, shutil, subprocess, tempfile, datetime

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
APP = os.environ.get('REASONIX_APP') or r'J:\Reasonix Studio'
TEMP_ROOT = os.environ.get('REASONIX_TEMP') or r'G:\Temp'
ASAR = os.path.join(APP, 'resources', 'app.asar')
BACKUPS = os.path.join(ROOT, 'backups')
PATCHES = os.path.join(HERE, 'asar_patches.json')
LOCAL_ASAR = os.path.join(HERE, 'node_modules', 'asar')
ASAR_MOD = os.environ.get('REASONIX_ASAR_MOD') or (
    LOCAL_ASAR if os.path.isdir(LOCAL_ASAR) else r'J:\.Reasonix-Studio\Reasonix-FR-Dev\build\tools\node_modules\asar')
DRY = '--dry-run' in sys.argv
FILES = ['starting.js', 'editmenu.js', 'uilang.js', 'hostexit.js', 'shelllog.js', 'packagegrants.js', 'main.js', 'tray.js']

os.makedirs(TEMP_ROOT, exist_ok=True)
tempfile.tempdir = TEMP_ROOT

def log(msg):
    print(msg, flush=True)

def find_node():
    exe = os.environ.get('REASONIX_NODE')
    if exe and os.path.isfile(exe):
        return exe, {}
    found = shutil.which('node')
    if found:
        return found, {}
    electron = os.path.join(APP, 'Reasonix Studio.exe')
    if os.path.isfile(electron):
        return electron, {'ELECTRON_RUN_AS_NODE': '1'}
    raise SystemExit('node introuvable : installe Node.js, ou garde Reasonix Studio installe (son Electron sert de node).')

def node(js, *args):
    exe, extra = find_node()
    env = os.environ.copy()
    env.update(extra)
    r = subprocess.run([exe, '-e', js] + list(args), capture_output=True, text=True, env=env)
    if r.returncode != 0:
        raise SystemExit('node : %s' % (r.stderr or r.stdout))
    return r.stdout

def extract(src, dst):
    node("require(process.argv[1]).extractAll(process.argv[2],process.argv[3])", ASAR_MOD, src, dst)

def pack(src, dst):
    node("const a=require(process.argv[1]);a.createPackage(process.argv[2],process.argv[3]).then(()=>process.exit(0))", ASAR_MOD, src, dst)

def check_js(path):
    exe, extra = find_node()
    env = os.environ.copy()
    env.update(extra)
    r = subprocess.run([exe, '--check', path], capture_output=True, text=True, env=env)
    if r.returncode != 0:
        raise SystemExit('syntaxe invalide : %s\n%s' % (os.path.basename(path), r.stderr))

def verify(root):
    checks = [
        ('starting.js', 'd\u00e9marre'),
        ('editmenu.js', '\u00c9dition'),
        ('tray.js', 'Rien en cours'),
        ('uilang.js', 'isFrench'),
    ]
    ok = 0
    for f, needle in checks:
        p = os.path.join(root, 'src', f)
        if os.path.isfile(p) and needle in open(p, encoding='utf-8').read():
            ok += 1
    return ok, len(checks)

def main():
    log('Reasonix Studio : %s' % APP)
    log('Temporaire      : %s' % TEMP_ROOT)
    if not os.path.isfile(ASAR):
        raise SystemExit('app.asar introuvable : %s' % ASAR)
    if not os.path.isdir(ASAR_MOD):
        raise SystemExit('module asar introuvable : %s' % ASAR_MOD)

    work = tempfile.mkdtemp(prefix='asar248-', dir=TEMP_ROOT)
    src = os.path.join(work, 'orig')
    out = os.path.join(work, 'fr')
    log('extraction...')
    extract(ASAR, src)

    pkg = json.load(open(os.path.join(src, 'package.json'), encoding='utf-8'))
    log('app.asar : %s %s' % (pkg.get('name'), pkg.get('version')))

    # deja patche ? on ne repack pas, on ne touche a rien
    def contains(rel, needle):
        p = os.path.join(src, 'src', rel)
        if not os.path.isfile(p):
            return False
        return needle in open(p, encoding='utf-8').read()
    if contains('uilang.js', 'isFrench') and contains('editmenu.js', '\u00c9dition'):
        log('app.asar : deja patche, rien a faire')
        return

    shutil.copytree(src, out)

    items = json.load(open(PATCHES, encoding='utf-8'))
    missed = []
    for item in items:
        p = os.path.join(out, 'src', item['file'])
        s = open(p, encoding='utf-8').read()
        for r in item['reps']:
            c = s.count(r['old'])
            if c != 1:
                missed.append((item['file'], r['tag'], c))
                continue
            s = s.replace(r['old'], r['new'], 1)
            log('  ok %-18s %s' % (item['file'], r['tag']))
        open(p, 'w', encoding='utf-8', newline='').write(s)

    if missed:
        log('MOTIFS NON APPLIQUES :')
        for m in missed:
            log('  %-18s %-18s %d' % m)
        raise SystemExit('patch natif interrompu : aucun fichier installe n\'a ete modifie')

    for f in FILES:
        check_js(os.path.join(out, 'src', f))
    log('syntaxe : OK sur les %d fichiers' % len(FILES))

    dest = os.path.join(work, 'app-fr.asar')
    pack(out, dest)
    log('asar reconstruit : %d octets' % os.path.getsize(dest))

    check = os.path.join(work, 'check')
    extract(dest, check)
    ok, total = verify(check)
    log('verification du paquet : %d/%d marqueurs' % (ok, total))
    if ok != total:
        raise SystemExit('verification echouee : rien n\'a ete installe')

    if DRY:
        log('(dry-run) app.asar non remplace ; copie disponible dans %s' % dest)
        return

    os.makedirs(BACKUPS, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    bak = os.path.join(BACKUPS, '%s__app.asar' % stamp)
    shutil.copy2(ASAR, bak)
    staged = ASAR + '.fr-new'
    shutil.copy2(dest, staged)
    try:
        os.replace(staged, ASAR)   # remplacement atomique
    except PermissionError:
        try:
            os.remove(staged)
        except OSError:
            pass
        log('')
        log('ECHEC : app.asar est verrouille par Reasonix Studio.')
        log('Ferme completement l\'application (zone de notification : Quitter),')
        log('puis relance ce script ou Francisation_2.49.bat.')
        raise SystemExit(2)
    log('app.asar remplace (sauvegarde : %s)' % os.path.basename(bak))

    installed = os.path.join(work, 'installed')
    extract(ASAR, installed)
    ok, total = verify(installed)
    log('verification installee : %d/%d marqueurs' % (ok, total))
    if ok != total:
        raise SystemExit('verification echouee')

if __name__ == '__main__':
    main()
