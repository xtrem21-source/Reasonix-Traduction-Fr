/* Construit dict\fr_dict_252.json :
   base fr_dict_249 + 174 traductions neuves (tr_252.json, indexees) + 9 corrections (ov_252.json).
   Controle avant d'ecrire : couverture totale, placeholders preserves, aucun chinois.
   Usage : node tools\build_fr252.js
*/
const fs = require('fs');
const path = require('path');
const ROOT = path.dirname(__dirname);
const D = path.join(ROOT, 'dict');
const P = path.join(D, 'parts');
const rd = f => JSON.parse(fs.readFileSync(f, 'utf8'));

const en = rd(path.join(D, 'en_dict_252.json'));
const base = rd(path.join(D, 'fr_dict_249.json'));
const missing = rd(path.join(P, 'a_traduire_252.json'));   // {zh: en}, ordre stable
const tr = rd(path.join(P, 'tr_252.json'));               // {"1": "..."}
const eng = rd(path.join(P, 'anglais_restant.json'));     // [{zh,en,fr}]
const ov = rd(path.join(P, 'ov_252.json'));               // {"3": "..."}

const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;
const ph = s => (String(s).match(/\{(\w+)\}/g) || []).sort().join(',');
const problems = [];

// 1. les 174 chaines neuves
const keys = Object.keys(missing);
if (keys.length !== 174) problems.push('a_traduire_252 : ' + keys.length + ' cles au lieu de 174');
const frNew = {};
keys.forEach((k, i) => {
  const v = tr[String(i + 1)];
  if (typeof v !== 'string' || !v.trim()) { problems.push('traduction manquante pour le rang ' + (i + 1)); return; }
  if (CJK.test(v)) problems.push('chinois dans la traduction ' + (i + 1));
  if (ph(v) !== ph(missing[k])) problems.push('placeholders differents au rang ' + (i + 1) + ' : ' + ph(v) + ' vs ' + ph(missing[k]));
  frNew[k] = v;
});

// 2. les corrections d'entrees restees en anglais
const frOv = {};
Object.entries(ov).forEach(([idx, v]) => {
  const row = eng[Number(idx) - 1];
  if (!row) { problems.push('rang override inconnu : ' + idx); return; }
  if (CJK.test(v)) problems.push('chinois dans la correction ' + idx);
  if (ph(v) !== ph(row.en)) problems.push('placeholders differents (correction ' + idx + ')');
  frOv[row.zh] = v;
});

// 3. fusion
const fr = Object.assign({}, base, frOv, frNew);

// 4. controles finaux
const absent = Object.keys(en).filter(k => !(k in fr));
if (absent.length) problems.push('cles du build sans traduction : ' + absent.length);
const blank = Object.keys(fr).filter(k => typeof fr[k] !== 'string' || !fr[k].trim());
if (blank.length) problems.push('traductions vides : ' + blank.length);
const cjkValues = Object.keys(fr).filter(k => (k in en) && CJK.test(fr[k]));
if (cjkValues.length) problems.push('valeurs chinoises : ' + cjkValues.length);

if (problems.length) {
  console.log('ECHEC :');
  problems.slice(0, 40).forEach(p => console.log('  - ' + p));
  console.log('total problemes :', problems.length);
  process.exit(1);
}

fs.writeFileSync(path.join(D, 'fr_dict_252.json'), JSON.stringify(fr, null, 0), 'utf8');
console.log('catalogue 2.52        :', Object.keys(en).length);
console.log('base 2.49             :', Object.keys(base).length);
console.log('traductions neuves    :', Object.keys(frNew).length);
console.log('corrections anglais   :', Object.keys(frOv).length);
console.log('fr_dict_252           :', Object.keys(fr).length);
console.log('couverture du build   : 100,00 %');
