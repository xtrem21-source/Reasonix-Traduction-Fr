/* Verifie que CHAQUE litteral chinois des bundles charges est une cle du dictionnaire.
   Sortie : dict/parts/cles_orphelines.json + resume
   Distingue : litteral passe a une fonction (traduit si cle presente)
               litteral brut (affiche tel quel -> chinois visible)
*/
const fs = require('fs');
const path = require('path');
const ROOT = path.dirname(__dirname);
const APP = process.env.REASONIX_APP || 'J:\\Reasonix Studio';
const DIST = path.join(APP, 'resources', 'frontend-next', 'dist');
const ASSETS = path.join(DIST, 'assets');
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;

const dict = JSON.parse(fs.readFileSync(path.join(ROOT, 'dict', 'en_dict_252.json'), 'utf8'));

const entry = fs.readFileSync(path.join(DIST, 'index.html'), 'utf8');
const seen = new Set();
const queue = [...entry.matchAll(/(?:\.\/)?([A-Za-z0-9_.-]+\.js)/g)].map(m => m[1]).filter(n => fs.existsSync(path.join(ASSETS, n)));
while (queue.length) {
  const n = queue.pop();
  if (seen.has(n)) continue;
  seen.add(n);
  const s = fs.readFileSync(path.join(ASSETS, n), 'utf8');
  for (const m of s.matchAll(/([A-Za-z0-9_.-]+\.js)/g)) {
    if (!seen.has(m[1]) && fs.existsSync(path.join(ASSETS, m[1]))) queue.push(m[1]);
  }
}

const orphan = [], raw = [], unknown = new Map();
let total = 0;
for (const n of [...seen].sort()) {
  if (/^i18n-/.test(n)) continue;
  const s = fs.readFileSync(path.join(ASSETS, n), 'utf8');
  const re = /[`"']([^`"'\n]{1,300})[`"']/g;
  let m;
  while ((m = re.exec(s))) {
    const lit = m[1];
    if (!CJK.test(lit)) continue;
    total++;
    const before = s.slice(Math.max(0, m.index - 40), m.index);
    const call = /([A-Za-z_$][\w$]*)\(\s*$/.exec(before);
    const isCall = !!call;
    if (!(lit in dict)) {
      orphan.push({ file: n, raw: !isCall, call: call ? call[1] : null, text: lit });
      unknown.set(lit, (unknown.get(lit) || 0) + 1);
    } else if (!isCall) {
      raw.push({ file: n, text: lit });
    }
  }
}

fs.writeFileSync(path.join(ROOT, 'dict', 'parts', 'cles_orphelines.json'),
  JSON.stringify({ orphan, raw }, null, 0), 'utf8');

console.log('litteraux chinois examines :', total);
console.log('cles absentes du dictionnaire :', orphan.length, '(distinctes :', unknown.size + ')');
console.log('litteraux bruts traduisibles mais affiches tels quels :', raw.length);
console.log('\n--- cles absentes (40) ---');
[...unknown.keys()].slice(0, 40).forEach(t => console.log('  ' + t));
console.log('\n--- litteraux bruts (30) ---');
raw.slice(0, 30).forEach(r => console.log('  ' + r.file + '  ' + r.text));
