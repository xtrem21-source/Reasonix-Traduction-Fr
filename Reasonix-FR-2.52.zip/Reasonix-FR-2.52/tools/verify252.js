/* Controle d'EXECUTION du patch : le bundle installe, charge avec la langue `fr`,
   rend-il du francais pour CHAQUE cle du catalogue ?
   Usage : node tools\verify252.js [--bundle <chemin i18n.js>]
   Sortie : code 0 si tout passe, 1 sinon.
*/
const fs = require('fs');
const path = require('path');

const ROOT = path.dirname(__dirname);
const APP = process.env.REASONIX_APP || 'J:\\Reasonix Studio';
const DIST = path.join(APP, 'resources', 'frontend-next', 'dist');
const D = path.join(ROOT, 'dict');
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;

const en = JSON.parse(fs.readFileSync(path.join(D, 'en_dict_252.json'), 'utf8'));
const fr = JSON.parse(fs.readFileSync(path.join(D, 'fr_dict_252.json'), 'utf8'));

// entrees ou l'anglais est legitimement identique au francais
const SAME_OK = new Set([
  'Zoom', 'Total', 'Version', 'Description', 'Module', 'Mentor', 'Douyin',
  'WeChat Pay', 'Alipay', 'SearXNG', 'Distribution', 'Machine', 'Assistant',
  'Agent', 'Conversation', 'Pause', 'Plan', 'Type', 'Interface', 'Compact',
  'Standard', 'Monospace', 'Palette', 'Terminal', 'Notifications', 'Proxy',
  'Port', 'Session', 'Direct', 'Vision', 'Action', 'Cache', 'Minimum',
]);

function loadBundle(file, lang) {
  let src = fs.readFileSync(file, 'utf8').replace(/export\s*\{[^}]*\}\s*;?/, '');
  const store = lang ? { 'rx-lang': lang } : {};
  globalThis.localStorage = {
    getItem: k => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: k => { delete store[k]; },
  };
  globalThis.document = { documentElement: { lang: '' } };
  globalThis.navigator = { languages: [lang === 'fr' ? 'fr-FR' : 'en-US'], language: lang === 'fr' ? 'fr-FR' : 'en-US' };
  globalThis.location = { reload: () => {} };
  const run = new Function(src + '\n;w();return {o: A, x: x, doc: document.documentElement.lang};');
  return run();
}

const arg = process.argv.indexOf('--bundle');
let bundle = arg > -1 ? process.argv[arg + 1] : null;
if (!bundle) {
  const html = fs.readFileSync(path.join(DIST, 'index.html'), 'utf8');
  const m = html.match(/(i18n-[A-Za-z0-9_-]+\.js)/);
  if (!m) { console.error('bundle i18n introuvable dans index.html'); process.exit(1); }
  bundle = path.join(DIST, 'assets', m[1]);
}

const bad = [];
const same = [];
const api = loadBundle(bundle, 'fr');
if (api.x !== 'fr') bad.push('langue active = ' + api.x + ' (attendu fr)');
if (api.doc !== 'fr') bad.push('document.documentElement.lang = ' + api.doc);

let checked = 0;
for (const k of Object.keys(en)) {
  const got = api.o(k);
  checked++;
  if (CJK.test(got)) { bad.push('CHINOIS : ' + k + ' => ' + got); continue; }
  if (got !== fr[k]) { bad.push('DIFFERENT : ' + k + ' => ' + got + ' (attendu ' + fr[k] + ')'); continue; }
  if (got === en[k] && !SAME_OK.has(got)) same.push(got);
}

// Les valeurs identiques a l'anglais ne sont pas des oublis : nombre d'entre
// elles s'ecrivent pareil en francais (Date, Total, ms, Session, Source...).
// On les liste pour arbitrage, sans faire echouer le controle.

// sante de l'anglais : le dictionnaire ne doit pas ecraser le mode en
// Cas qui echouait : aucun reglage enregistre + machine non francaise.
const apiDefaut = loadBundle(bundle, null);
if (apiDefaut.x !== 'fr') bad.push('defaut sans reglage = ' + apiDefaut.x + ' (attendu fr)');
const apiEn = loadBundle(bundle, 'en');
let enDiff = 0;
for (const k of Object.keys(en)) if (apiEn.o(k) !== en[k]) enDiff++;

console.log('bundle        :', path.basename(bundle));
console.log('cles verifiees :', checked);
console.log('mode fr        :', api.x, '/', api.doc);
console.log('mode en intact :', enDiff === 0 ? 'oui' : (enDiff + ' ecarts'));
console.log('erreurs        :', bad.length);
bad.slice(0, 25).forEach(b => console.log('  - ' + b));
const uniq = [...new Set(same)].sort();
console.log('identiques a l anglais (a arbitrer) :', uniq.length);
console.log('  ' + uniq.join(' | '));
process.exit(bad.length ? 1 : 0);
