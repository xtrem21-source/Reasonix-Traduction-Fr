/* Liste les entrees FR identiques a l'anglais, avec leur cle chinoise, dans l'ordre stable
   de dict/en_dict_252.json. Sortie : dict/parts/anglais_restant.json (tableau ordonne). */
const fs = require('fs');
const path = require('path');
const D = path.join(path.dirname(__dirname), 'dict');
const en = JSON.parse(fs.readFileSync(path.join(D, 'en_dict_252.json'), 'utf8'));
const fr = JSON.parse(fs.readFileSync(path.join(D, 'fr_dict_249.json'), 'utf8'));
const rows = [];
for (const k of Object.keys(en)) {
  if (k in fr && fr[k] === en[k] && fr[k].trim()) rows.push({ zh: k, en: en[k], fr: fr[k] });
}
fs.writeFileSync(path.join(D, 'parts', 'anglais_restant.json'), JSON.stringify(rows, null, 0), 'utf8');
rows.forEach((r, i) => console.log((i + 1) + '. ' + JSON.stringify(r.en) + '   # ' + r.zh));
console.log('\ntotal :', rows.length);
