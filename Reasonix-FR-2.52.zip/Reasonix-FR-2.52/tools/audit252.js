/* Audit du dictionnaire FR : valeurs chinoises ou restees identiques a l'anglais. */
const fs = require('fs');
const path = require('path');
const D = path.join(path.dirname(__dirname), 'dict');
const en = JSON.parse(fs.readFileSync(path.join(D, 'en_dict_252.json'), 'utf8'));
const fr = JSON.parse(fs.readFileSync(path.join(D, 'fr_dict_249.json'), 'utf8'));
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;

const cjk = [], same = [], empty = [], nofr = [];
for (const [k, v] of Object.entries(fr)) {
  if (!(k in en)) continue;               // cle obsolete : hors sujet
  if (typeof v !== 'string' || !v.trim()) { empty.push(k); continue; }
  if (CJK.test(v)) cjk.push([k, v, en[k]]);
  else if (v === en[k]) same.push([k, v]);
  else if (!/[a-zà-ÿ]/i.test(v)) nofr.push([k, v, en[k]]);
}
console.log('entrees FR applicables :', Object.keys(fr).filter(k => k in en).length);
console.log('valeurs chinoises      :', cjk.length);
console.log('vides                  :', empty.length);
console.log('identiques a l anglais :', same.length);
console.log('sans lettre            :', nofr.length);
console.log('\n--- valeurs chinoises ---');
cjk.slice(0, 30).forEach(r => console.log('  ' + r[0] + ' => ' + r[1]));
console.log('\n--- identiques a l anglais (echantillon) ---');
same.slice(0, 40).forEach(r => console.log('  ' + JSON.stringify(r[1])));
console.log('\n--- sans lettre ---');
nofr.slice(0, 20).forEach(r => console.log('  ' + JSON.stringify(r[1]) + '  [en=' + JSON.stringify(r[2]) + ']'));
