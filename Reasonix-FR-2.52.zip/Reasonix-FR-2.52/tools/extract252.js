/* Extrait le catalogue de chaines du bundle i18n REELLEMENT charge.
   Entree : <app>\resources\frontend-next\dist\index.html -> assets\i18n-*.js
   Sortie : dict\en_dict_252.json   {chinois: anglais}
            dict\zh_only_252.json   {chinois: ""}  cles sans traduction anglaise
   Usage  : node tools\extract252.js [chemin\vers\bundle.js]
*/
const fs = require('fs');
const path = require('path');

const ROOT = path.dirname(__dirname);
const APP = process.env.REASONIX_APP || 'J:\\Reasonix Studio';
const DIST = path.join(APP, 'resources', 'frontend-next', 'dist');

function liveBundle() {
  if (process.argv[2]) return process.argv[2];
  const html = fs.readFileSync(path.join(DIST, 'index.html'), 'utf8');
  const m = html.match(/(i18n-[A-Za-z0-9_-]+\.js)/);
  if (!m) throw new Error('bundle i18n introuvable dans index.html');
  return path.join(DIST, 'assets', m[1]);
}

const file = liveBundle();
let src = fs.readFileSync(file, 'utf8');
src = src.replace(/export\s*\{[^}]*\}\s*;?/, '');

// stubs : le module lit localStorage / navigator / document au chargement
globalThis.document = { documentElement: { lang: '' } };
globalThis.localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
globalThis.navigator = { languages: ['en'], language: 'en' };
globalThis.location = { reload: () => {} };

// Build 2.52 : b = { zh: {} , en: { chinois: anglais } } ; S = b[langue].
// Le catalogue reel est b.en (5146 entrees), b.zh est vide (le chinois s'affiche
// par identite : la cle EST le texte).
const dump = new Function(src + '\n;return {en: (typeof b!=="undefined"&&b.en)||{}, zh: (typeof b!=="undefined"&&b.zh)||{}, x: (typeof x!=="undefined"?x:null)};')();
const zh = dump.en;   // cle = texte chinois
const en = dump.en;   // valeur = texte anglais

const out = {};
const zhOnly = {};
for (const k of Object.keys(zh)) {
  const v = en[k];
  if (typeof v === 'string' && v.length) out[k] = v;
  else zhOnly[k] = '';
}

const dictDir = path.join(ROOT, 'dict');
fs.mkdirSync(dictDir, { recursive: true });
fs.writeFileSync(path.join(dictDir, 'en_dict_252.json'), JSON.stringify(out, null, 0), 'utf8');
fs.writeFileSync(path.join(dictDir, 'zh_only_252.json'), JSON.stringify(zhOnly, null, 0), 'utf8');

console.log('bundle        :', path.basename(file));
console.log('cles zh       :', Object.keys(zh).length);
console.log('avec anglais  :', Object.keys(out).length);
console.log('sans anglais  :', Object.keys(zhOnly).length);
console.log('langue active :', dump.x);
