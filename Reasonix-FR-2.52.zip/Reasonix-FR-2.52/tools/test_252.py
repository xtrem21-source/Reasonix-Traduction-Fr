"""Prouve que le pack 2.52 livre le defaut francais dans les DEUX chemins.

1. installation neuve  : R5 transforme l'original E() en E() francais par defaut ;
2. installation deja patchee : R6 rattrape l'ancien E() pour donner le meme texte.

Le test compare les deux chaines produites et verifie qu'elles sont identiques,
puis les execute pour confirmer que le resultat est bien `fr`.
Usage : python tools/test_252.py
"""
import os, sys, json, importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('p252', os.path.join(HERE, 'patch252.py'))
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

fr_par_defaut = p.default_fr()['new']
r5 = dict((n, new) for n, old, new in p.patches())['R5_machine']
r6_old, r6_new = dict((n, (old, new)) for n, old, new in p.upgrades())['R6_defaut_fr']

ok = True
def check(label, cond, detail=''):
    global ok
    print('%-46s %s%s' % (label, 'OK' if cond else 'ECHEC', ('  ' + detail) if detail and not cond else ''))
    ok = ok and cond

check('R5 (installation neuve) = R6 (rattrapage)', r5 == fr_par_defaut)
check('R6 ne s\'applique qu\'a l\'ancien texte', r6_new == fr_par_defaut)
check('R6 ancien texte different du nouveau', r6_old != r6_new)
check('defaut = fr sans machine francaise', ":%sfr%s}" % (p.BT, p.BT) in fr_par_defaut)
check('aucun retour a en dans le defaut', ":%sen%s" % (p.BT, p.BT) not in fr_par_defaut)
check('chinois toujours traite avant le defaut', "?%szh%s:" % (p.BT, p.BT) in fr_par_defaut)

print('')
print('texte livre :', fr_par_defaut)
sys.exit(0 if ok else 1)
