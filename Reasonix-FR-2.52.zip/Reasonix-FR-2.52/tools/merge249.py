"""Fusionne les lots de traduction dans le dictionnaire FR.

Base    : dict/fr_dict_248.json  (dictionnaire livre avec le paquet 2.48)
Lots    : dict/parts/batch_*.json  {chinois: francais}
Sortie  : dict/fr_dict_249.json

Reprise : la fusion est idempotente, un lot deja fusionne ne change rien.
Usage   : python tools/merge249.py
"""
import glob, io, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DICT = os.path.join(ROOT, 'dict')
BASE = os.path.join(DICT, 'fr_dict_248.json')
OUT = os.path.join(DICT, 'fr_dict_249.json')

base = json.load(io.open(BASE, encoding='utf-8'))
merged = dict(base)
added = {}
for path in sorted(glob.glob(os.path.join(DICT, 'parts', 'batch_*.json'))):
    part = json.load(io.open(path, encoding='utf-8'))
    for k, v in part.items():
        if k not in base:
            added[k] = v
    merged.update(part)
    print('%-28s %3d entrees' % (os.path.basename(path), len(part)))

json.dump(merged, io.open(OUT, 'w', encoding='utf-8', newline=''),
          ensure_ascii=False, sort_keys=True)
print('base 2.48     : %d entrees' % len(base))
print('nouvelles     : %d' % len(added))
print('fr_dict_249   : %d entrees' % len(merged))

missing = [k for k in added if k not in merged]
if missing:
    raise SystemExit('fusion incomplete : %d cle(s)' % len(missing))
