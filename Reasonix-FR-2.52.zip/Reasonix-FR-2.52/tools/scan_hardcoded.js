/* Scanne les bundles REELLEMENT charges et signale :
   - le chinois code en dur (litteral CJK) hors du bundle i18n ;
   - les libelles anglais codes en dur dans les enfants JSX (children:`...`).
   Sortie : rapport lisible sur stdout + dict/parts/hardcoded.json
*/
const fs = require('fs');
const path = require('path');
const APP = process.env.REASONIX_APP || 'J:\\Reasonix Studio';
const DIST = path.join(APP, 'resources', 'frontend-next', 'dist');
const ASSETS = path.join(DIST, 'assets');
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;

function load(html) { return fs.readFileSync(html, 'utf8'); }

// graphe des modules charges depuis index.html
const entry = load(path.join(DIST, 'index.html'));
const start = [...entry.matchAll(/(?:\.\/)?([A-Za-z0-9_.-]+\.js)/g)].map(m => m[1]);
const seen = new Set();
const queue = start.filter(n => fs.existsSync(path.join(ASSETS, n)));
while (queue.length) {
  const n = queue.pop();
  if (seen.has(n)) continue;
  seen.add(n);
  const s = fs.readFileSync(path.join(ASSETS, n), 'utf8');
  for (const m of s.matchAll(/([A-Za-z0-9_.-]+\.js)/g)) {
    const ref = m[1];
    if (!seen.has(ref) && fs.existsSync(path.join(ASSETS, ref))) queue.push(ref);
  }
}

const cjk = [], labels = [];
for (const n of [...seen].sort()) {
  if (/^i18n-/.test(n)) continue;               // catalogue : cles chinoises par nature
  const s = fs.readFileSync(path.join(ASSETS, n), 'utf8');
  // litteraux contenant du CJK
  const re = /[`"']([^`"'\n]{0,200})[`"']/g;
  let m;
  while ((m = re.exec(s))) {
    const lit = m[1];
    if (!CJK.test(lit)) continue;
    const before = s.slice(Math.max(0, m.index - 12), m.index);
    cjk.push({ file: n, before, text: lit.slice(0, 120) });
  }
  // libelles anglais dans children:
  for (const mm of s.matchAll(/children:\s*`([^`]{2,60})`/g)) {
    const t = mm[1];
    if (!/^[\x20-\x7e]+$/.test(t)) continue;
    if (!/[A-Za-z]{3,}\s+[A-Za-z]{2,}/.test(t) && !/^[A-Z][a-z]+$/.test(t)) continue;
    labels.push({ file: n, text: t });
  }
}

fs.writeFileSync(path.join(path.dirname(__dirname), 'dict', 'parts', 'hardcoded.json'),
  JSON.stringify({ cjk, labels }, null, 0), 'utf8');

const perFile = {};
for (const r of cjk) perFile[r.file] = (perFile[r.file] || 0) + 1;
console.log('modules charges :', seen.size);
console.log('chinois code en dur :', cjk.length);
console.log('libelles children: :', labels.length);
console.log('\n--- chinois par fichier ---');
Object.entries(perFile).sort((a, b) => b[1] - a[1]).forEach(([f, n]) => console.log('  ' + n + '\t' + f));
const translated = cjk.filter(r => /[\w,]\s*$/.test(r.before) && /[oAt]$/.test(r.before.trim()));
console.log('\n--- chinois hors appel de traduction (echantillon 40) ---');
cjk.filter(r => !/o\($|A\($|t\($/.test(r.before)).slice(0, 40).forEach(r => console.log('  ' + r.file + '  [' + r.before + ']  ' + r.text));
