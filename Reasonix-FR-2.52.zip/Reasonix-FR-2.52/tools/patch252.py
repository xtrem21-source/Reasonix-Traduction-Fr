"""Applique le patch francais a Reasonix Studio 2.52 (app installee).

Usage :
  python patch252.py --dry-run     # montre ce qui serait fait
  python patch252.py               # applique (sauvegardes horodatees)
  python patch252.py --restore     # remet les sauvegardes les plus recentes

Chemins : lus dans config.bat (REASONIX_APP, REASONIX_TEMP).

Ce qu'il fait :
  1. lit index.html pour trouver le bundle i18n REELLEMENT charge ;
  2. patch ce bundle (5 motifs propres a la 2.52 + dictionnaire FR 2.52) ;
  3. ajoute "Francais" au selecteur de langue du bundle Settings charge ;
  4. patch index.html (langue de l'ecran de demarrage) ;
  5. remplace les libelles anglais codes en dur des bundles charges ;
  6. verifie la syntaxe AVANT d'ecrire, puis les marqueurs.

Difference avec 2.49 : le build 2.52 a reecrit sa logique de langue
(b = { zh: {}, en: {...} }, S = b[x], A(e,t) = S[e] ?? e). Les six motifs
de 2.49 n'existent plus ; ceux ci-dessous sont ceux du build 2.52.

Idempotent : si globalThis.__FR est deja present, le dictionnaire est
seulement mis a jour.
"""
import os, sys, re, json, glob, shutil, datetime, subprocess, tempfile

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DICT = os.path.join(ROOT, 'dict', 'fr_dict_252.json')
BACKUPS = os.path.join(ROOT, 'backups')
APP = os.environ.get('REASONIX_APP') or r'J:\Reasonix Studio'
TEMP_ROOT = os.environ.get('REASONIX_TEMP') or r'G:\Temp'
DIST = os.path.join(APP, 'resources', 'frontend-next', 'dist')
ASSETS = os.path.join(DIST, 'assets')
DRY = '--dry-run' in sys.argv
RESTORE = '--restore' in sys.argv
BT = '`'

os.makedirs(TEMP_ROOT, exist_ok=True)
tempfile.tempdir = TEMP_ROOT

log_lines = []
def log(msg):
    print(msg, flush=True)
    log_lines.append(msg)

def stamp():
    return datetime.datetime.now().strftime('%Y%m%d-%H%M%S')

def backup(path, tag):
    os.makedirs(BACKUPS, exist_ok=True)
    dest = os.path.join(BACKUPS, '%s__%s__%s' % (stamp(), tag, os.path.basename(path)))
    shutil.copy2(path, dest)
    return dest

def read(p):
    return open(p, encoding='utf-8').read()

def write_atomic(p, s):
    tmp = p + '.tmp-fr'
    open(tmp, 'w', encoding='utf-8', newline='').write(s)
    os.replace(tmp, p)

def find_node():
    exe = os.environ.get('REASONIX_NODE')
    if exe and os.path.isfile(exe):
        return exe, {}
    found = shutil.which('node')
    if found:
        return found, {}
    electron = os.path.join(APP, 'Reasonix Studio.exe')
    if os.path.isfile(electron):
        return electron, {'ELECTRON_RUN_AS_NODE': '1'}
    raise SystemExit('node introuvable : installe Node.js, ou garde Reasonix Studio installe.')

def check_syntax_text(text):
    node, extra = find_node()
    tmp = os.path.join(tempfile.gettempdir(), 'check-fr-%d.mjs' % os.getpid())
    open(tmp, 'w', encoding='utf-8', newline='').write(text)
    env = os.environ.copy()
    env.update(extra)
    try:
        r = subprocess.run([node, '--check', tmp], capture_output=True, text=True, env=env)
        return r.returncode == 0, (r.stderr or '').strip()
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

def live_i18n():
    html = read(os.path.join(DIST, 'index.html'))
    m = re.search(r'/(i18n-[A-Za-z0-9_\-]+\.js)', html)
    if not m:
        raise SystemExit('bundle i18n introuvable dans index.html')
    return os.path.join(ASSETS, m.group(1))

def live_main():
    html = read(os.path.join(DIST, 'index.html'))
    m = re.search(r'/(index-[A-Za-z0-9_\-]+\.js)', html)
    return os.path.join(ASSETS, m.group(1)) if m else None

def selector_old():
    # selecteur 2.52 : [[``,`跟随系统`],[`zh`,`中文`],[`en`,`英文`]]
    return '[[%s%s,%s],[%s,%s],[%s,%s]]' % (
        BT, BT, BT + '跟随系统' + BT,
        BT + 'zh' + BT, BT + '中文' + BT,
        BT + 'en' + BT, BT + '英文' + BT)

def selector_new():
    return '[[%s%s,%s],[%s,%s],[%s,%s],[%s,%s]]' % (
        BT, BT, BT + '跟随系统' + BT,
        BT + 'zh' + BT, BT + '中文' + BT,
        BT + 'en' + BT, BT + '英文' + BT,
        BT + 'fr' + BT, BT + 'Français' + BT)

def live_settings():
    want = selector_old()
    done = selector_new()
    hits = []
    for p in glob.glob(os.path.join(ASSETS, 'Settings-*.js')):
        s = read(p)
        if want in s or done in s:
            hits.append(p)
    if not hits:
        raise SystemExit('selecteur de langue introuvable dans les bundles Settings')
    main = live_main()
    if main and os.path.isfile(main):
        for ref in re.findall(r'(Settings-[A-Za-z0-9_\-]+\.js)', read(main)):
            p = os.path.join(ASSETS, ref)
            if p in hits:
                log('  Settings : %s (charge par %s)' % (ref, os.path.basename(main)))
                return p
    hits.sort(key=os.path.getmtime, reverse=True)
    log('  Settings : %s (le plus recent)' % os.path.basename(hits[0]))
    return hits[0]

def patches():
    """Motifs du build 2.52. Chacun doit apparaitre exactement une fois."""
    return [
        ('R1_traduire',
         'function A(e,t){let n=S[e]??e;',
         'function A(e,t){let n=(x===%sfr%s?globalThis.__FR?.[e]:void 0)??S[e]??e;' % (BT, BT)),
        ('R2_resolve',
         'return t===%szh%s||t===%sen%s?t:E()' % (BT, BT, BT, BT),
         'return t===%szh%s||t===%sen%s||t===%sfr%s?t:E()' % (BT, BT, BT, BT, BT, BT)),
        ('R3_lang',
         'document.documentElement.lang=x===%szh%s?%szh-CN%s:%sen%s' % (BT, BT, BT, BT, BT, BT),
         'document.documentElement.lang=x===%szh%s?%szh-CN%s:x===%sfr%s?%sfr%s:%sen%s' % (BT, BT, BT, BT, BT, BT, BT, BT, BT, BT)),
        ('R4_dict',
         'S=b[x],document.documentElement.lang',
         'S=b[x]??globalThis.__FR??b.en,document.documentElement.lang'),
        ('R5_machine',
         'function E(){return D(navigator.languages?.[0]??navigator.language??%s%s)?%szh%s:%sen%s}' % (BT, BT, BT, BT, BT, BT),
         default_fr()['new']),
    ]

def default_fr():
    """Sans langue enregistree, le francais remplace l'anglais.

    Pourquoi (constat 2.52) : preload.js restaure les preferences rx-* depuis
    window-prefs.json ; ce fichier n'est pas ecrit sur cette installation, et
    l'origine change a chaque lancement (port du noyau neuf). localStorage est
    donc vide au demarrage : la langue retombait sur celle de la machine, donc
    l'anglais. Le choix "Francais" ne survivait jamais au rechargement.
    """
    return {
        'old': 'function E(){let L=navigator.languages?.[0]??navigator.language??%s%s;return D(L)?%szh%s:L.toLowerCase().startsWith(%sfr%s)?%sfr%s:%sen%s}' % (BT, BT, BT, BT, BT, BT, BT, BT, BT, BT),
        'new': 'function E(){let L=navigator.languages?.[0]??navigator.language??%s%s;return D(L)?%szh%s:%sfr%s}' % (BT, BT, BT, BT, BT, BT),
    }

# Rattrapage d'un bundle deja patche par la version precedente du script.
def upgrades():
    d = default_fr()
    return [('R6_defaut_fr', d['old'], d['new'])]

def apply_i18n(path, fr):
    s = read(path)
    payload = json.dumps(fr, ensure_ascii=False, separators=(',', ':'))

    if 'globalThis.__FR' in s:
        log('  i18n : deja patche')
        m = s.rfind('globalThis.__FR=')
        # Fin du bloc : le dictionnaire JSON est compact (aucun saut de ligne),
        # donc le premier ";\n" apres son debut le termine. Chercher un simple
        # ';' tombait sur un point-virgule situe DANS une traduction.
        j = s.find(';\n', m)
        if m < 0 or j < 0:
            log('  !! dictionnaire existant illisible : pas de mise a jour')
            return False
        new = s[:m] + 'globalThis.__FR=' + payload + s[j:]
        # Rattrapage des correctifs posterieurs a la premiere pose : le defaut
        # francais (R6) doit s'appliquer aussi a un bundle deja patche.
        for name, old, rep in upgrades():
            c = new.count(old)
            if c == 1:
                new = new.replace(old, rep, 1)
                log('  ok %s (rattrapage)' % name)
            elif new.count(rep) == 1:
                log('  %s : deja applique' % name)
            else:
                log('  %s : motif absent (%d occurrence(s))' % (name, c))
        if new == s:
            log('  dictionnaire deja a jour (%d entrees)' % len(fr))
            return False
        ok, err = check_syntax_text(new)
        log('  syntaxe i18n (avant ecriture) : %s' % ('OK' if ok else 'ECHEC'))
        if not ok:
            log(err)
            raise SystemExit(1)
        if DRY:
            log('  (dry-run) dictionnaire non mis a jour (%d entrees)' % len(fr))
            return False
        b = backup(path, 'i18n')
        write_atomic(path, new)
        log('  dictionnaire mis a jour : %d entrees (sauvegarde %s)' % (len(fr), os.path.basename(b)))
        return True

    for name, old, new in patches():
        c = s.count(old)
        if c != 1:
            raise SystemExit('motif %s : %d occurrence(s) au lieu de 1' % (name, c))
        s = s.replace(old, new, 1)
        log('  ok %s' % name)
    s = s + '\n;globalThis.__FR=' + payload + ';\n'

    ok, err = check_syntax_text(s)
    log('  syntaxe i18n (avant ecriture) : %s' % ('OK' if ok else 'ECHEC'))
    if not ok:
        log(err)
        raise SystemExit(1)
    if DRY:
        log('  (dry-run) i18n non ecrit, %d entrees FR' % len(fr))
        return False
    b = backup(path, 'i18n')
    write_atomic(path, s)
    log('  ecrit %s (sauvegarde %s)' % (os.path.basename(path), os.path.basename(b)))
    return True

def apply_settings(path):
    s = read(path)
    old, new = selector_old(), selector_new()
    if s.count(old) == 1:
        if DRY:
            log('  (dry-run) Settings non ecrit')
            return False
        b = backup(path, 'settings')
        write_atomic(path, s.replace(old, new, 1))
        log('  ecrit %s (sauvegarde %s)' % (os.path.basename(path), os.path.basename(b)))
        return True
    if s.count(new) == 1:
        log('  Settings : deja patche')
        return False
    raise SystemExit('selecteur Settings : motif introuvable (%d original, %d patche)'
                     % (s.count(old), s.count(new)))

def apply_index():
    p = os.path.join(DIST, 'index.html')
    s = read(p)
    old_zh = 'var zh = p === "zh" || (p !== "en" && /^(zh|yue|cmn)/i.test(navigator.language || ""));'
    new_fr = ('var fr = p === "fr" || (p !== "zh" && p !== "en" && /^fr/i.test(navigator.language || ""));\n'
              '          var zh = !fr && (p === "zh" || (p !== "en" && /^(zh|yue|cmn)/i.test(navigator.language || "")));')
    old_lang = 'document.documentElement.lang = zh ? "zh-CN" : "en";'
    new_lang = 'document.documentElement.lang = p === "fr" ? "fr" : zh ? "zh-CN" : "en";'

    changed = False
    if new_lang in s:
        log('  index.html : deja patche')
        return False
    if s.count(old_zh) != 1 or s.count(old_lang) != 1:
        raise SystemExit('index.html : motifs introuvables (%d / %d)' % (s.count(old_zh), s.count(old_lang)))
    if DRY:
        log('  (dry-run) index.html non ecrit')
        return False
    s = s.replace(old_zh, new_fr, 1).replace(old_lang, new_lang, 1)
    b = backup(p, 'index')
    write_atomic(p, s)
    log('  ecrit index.html (sauvegarde %s)' % os.path.basename(b))
    return True


# Libelles anglais cables en dur : ils ne passent pas par la fonction de
# traduction, donc le dictionnaire ne peut pas les couvrir.
# (bundle logique, motif attendu, remplacement, occurrences attendues)
LABELS = [
    ('settings', 'children:%sAPI Key%s' % (BT, BT), 'children:%sClé API%s' % (BT, BT), 1),
    ('settings', 'children:%sTokens%s' % (BT, BT), 'children:%sJetons%s' % (BT, BT), 2),
    ('settings', 'children:%sTurns%s' % (BT, BT), 'children:%sTours%s' % (BT, BT), 1),
    ('main', 'children:%sMODEL CONNECTION%s' % (BT, BT), 'children:%sCONNEXION AU MODÈLE%s' % (BT, BT), 1),
    ('main', 'children:%scoding agent%s' % (BT, BT), 'children:%sagent de code%s' % (BT, BT), 1),
]


def apply_labels(bundles):
    changed = 0
    for which, old, new, expected in LABELS:
        path = bundles.get(which)
        if not path or not os.path.isfile(path):
            log('  libelle %-26s bundle %s introuvable' % (old, which))
            continue
        s = read(path)
        n_old = s.count(old)
        n_new = s.count(new)
        if n_old == 0:
            if n_new:
                log('  libelle %-26s deja remplace' % old)
            else:
                log('  libelle %-26s motif absent' % old)
            continue
        if n_old != expected:
            raise SystemExit('libelle %s : %d occurrence(s) au lieu de %d' % (old, n_old, expected))
        if DRY:
            log('  (dry-run) libelle %-26s -> %s' % (old, new))
            continue
        b = backup(path, 'labels')
        write_atomic(path, s.replace(old, new))
        changed += 1
        log('  libelle %-26s -> %s (sauvegarde %s)' % (old, new, os.path.basename(b)))
    return changed


def main():
    log('Reasonix Studio : %s' % APP)
    log('Temporaire      : %s' % TEMP_ROOT)
    if not os.path.isdir(DIST):
        raise SystemExit('installation introuvable : %s' % DIST)

    if RESTORE:
        if not os.path.isdir(BACKUPS):
            raise SystemExit('aucune sauvegarde')
        done = set()
        for p in sorted(glob.glob(os.path.join(BACKUPS, '*')), key=os.path.getmtime, reverse=True):
            name = os.path.basename(p)
            target_name = name.split('__', 2)[-1]
            target = os.path.join(ASSETS, target_name)
            if target_name in done or not os.path.exists(target):
                continue
            shutil.copy2(p, target)
            done.add(target_name)
            log('restaure %s <- %s' % (target_name, name))
        return

    if not os.path.exists(DICT):
        raise SystemExit('dictionnaire absent : %s' % DICT)
    fr = json.load(open(DICT, encoding='utf-8'))
    log('dictionnaire FR : %d entrees' % len(fr))

    i18n = live_i18n()
    settings = live_settings()
    log('bundle i18n     : %s' % os.path.basename(i18n))
    log('bundle Settings : %s' % os.path.basename(settings))

    changed = apply_i18n(i18n, fr)
    apply_settings(settings)
    apply_index()
    apply_labels({'main': live_main(), 'settings': settings})

    if changed and not DRY:
        ok, err = check_syntax_text(read(i18n))
        log('syntaxe i18n (fichier installe) : %s' % ('OK' if ok else 'ECHEC'))
        if not ok:
            log(err)
            raise SystemExit(1)
        s = read(i18n)
        log('marqueurs : __FR=%d' % s.count('globalThis.__FR'))
    log('')
    if DRY:
        log('DRY-RUN TERMINE. Rien n\'a ete ecrit dans Reasonix Studio.')
    else:
        log('TERMINE. Relance Reasonix Studio, puis choisis Francais dans Parametres > Apparence > Langue.')

if __name__ == '__main__':
    main()
