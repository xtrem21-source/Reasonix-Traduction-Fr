# Francisation Reasonix Studio 2.52

> Patch de l'application installée dans **`J:\Reasonix Studio`**. Réversible : chaque fichier modifié est sauvegardé dans `backups\`.
> Aucun fichier temporaire n'est écrit sur `C:` : tout passe par **`G:\Temp`**.

## Ce que fait ce paquet

| Étape | Contenu |
|---|---|
| Interface (`frontend-next`) | dictionnaire FR de **5 221 entrées**, injecté dans le bundle i18n réellement chargé ; le sélecteur de langue reçoit **Français** |
| Couverture | **100 %** des 5 146 chaînes du build 2.52 (5 047 reprises de la 2.49 + **174 traduites** + 9 corrections d'entrées restées en anglais) |
| Chaînes natives (`app.asar`) | page de démarrage, menu contextuel, menu du tray, dialogues de plantage, dialogue d'ancienne version — 11 remplacements |
| Écran de démarrage HTML | reconnaît `fr` au lieu de retomber sur l'anglais |
| Libellés codés en dur | `Clé API`, `Jetons`, `Tours`, `CONNEXION AU MODÈLE`, `agent de code` |

Le paquet **détecte** les fichiers à patcher au lieu de coder leurs noms en dur : il lit `index.html` pour trouver le bundle i18n courant, puis choisit le bundle `Settings-*.js` que le bundle principal charge réellement.

## Ce qui a changé depuis la 2.49

Le build 2.52 a **réécrit sa logique de langue**. Les six motifs du patch 2.49 n'existent plus :

| 2.49 | 2.52 |
|---|---|
| `function O(e,t){let n=b[e]??e;` | `function A(e,t){let n=S[e]??e;` |
| `b=v[y]` (carte par langue) | `S=b[x],` avec `b={zh:{},en:{…}}` |
| `[[`跟随系统`],[`zh`,`中文`],[`en`,`英文`]]` | `[[``,`跟随系统`],[`zh`,`中文`],[`en`,`英文`]]` |

Les motifs 2.52 sont dans `tools\patch252.py`, la section `patches()`.

## Langue par défaut (correctif du 26/10, après ton retour)

**Symptôme** : choisir « Français » rechargeait la fenêtre… qui revenait en anglais.

**Cause réelle**, vérifiée dans le code du shell 2.52 :

| Maillon | Constat |
|---|---|
| `preload.js` | restaure les préférences `rx-*` depuis `window-prefs.json` — **ce fichier n'est pas écrit** sur cette installation |
| origine du page | le noyau écoute sur un **port différent à chaque lancement** → `localStorage` est vide au démarrage |
| `i18n` (R5) | sans valeur enregistrée, la langue retombait sur celle de la machine → `en` |
| `uilang.js` (natif) | n'accepte que `zh`/`en` : il ne pouvait pas non plus rétablir `fr` |

Donc le choix ne survivait jamais : à chaque rechargement, plus rien en mémoire, retour à l'anglais.

**Correctif** : sans langue enregistrée, le français devient le défaut (le chinois reste détecté en premier).

```js
function E(){let L=navigator.languages?.[0]??navigator.language??``;return D(L)?`zh`:`fr`}
```

| Chemin | Motif |
|---|---|
| installation neuve | `R5_machine` produit directement ce texte |
| installation déjà patchée | `R6_defaut_fr` rattrape l'ancien `E()` et le remplace |

Les deux chemins sont prouvés identiques par `tools\test_252.py` (6 contrôles, code 0 attendu) :

```text
python tools\test_252.py
```

Le sélecteur reste fonctionnel : un `rx-lang` explicite (`en`, `zh`, `fr`) est toujours honoré ; c'est seulement l'**absence** de choix qui donne le français.

## État vérifié du build 2.52

| Élément | Valeur constatée |
|---|---|
| Version | 2.52.0 (`Reasonix Studio.exe`, `app.asar`) |
| Bundle i18n chargé | `assets\i18n-DunoFOkp.js` (5 146 entrées) |
| Bundle principal | `assets\index-B26539c_.js` |
| Bundle Settings chargé | `assets\Settings-Bj8eAezi.js` |
| Motifs du patch | 5/5 sur le bundle i18n, sélecteur de langue présent, 2/2 motifs d'`index.html` |
| Motifs natifs | 11 remplacements sur 8 fichiers, 4/4 marqueurs après reconstruction |

Contrôle rejouable sans rien écrire :

```text
py tools\patch252.py --dry-run
py tools\patch_asar252.py --dry-run
node tools\verify252.js --source-only
```

## Variables

Tout est centralisé dans **`config.bat`** :

| Variable | Valeur par défaut | Rôle |
|---|---|---|
| `REASONIX_APP` | `J:\Reasonix Studio` | dossier d'installation de Studio |
| `REASONIX_TEMP` | `G:\Temp` | dossier temporaire (jamais `C:`) |
| `REASONIX_PY` | Python 3.13, sinon `python` | interpréteur |
| `REASONIX_NODE` | vide | Node.js facultatif ; sinon l'Electron de Studio sert de Node |

Modifie uniquement ce fichier si l'installation change de disque.

## Utilisation

```text
1. Fermer complètement Reasonix Studio
   (icône de la zone de notification → Quitter)
2. Double-cliquer Francisation_2.52.bat
3. Rouvrir Reasonix Studio
4. Paramètres → Apparence → Langue → Français
```

En cas d'échec, le `.bat` s'arrête et affiche la raison. Le patch natif vérifie la syntaxe des 8 fichiers et le paquet reconstruit **avant** de remplacer `app.asar` : il ne s'installe jamais à moitié.

## Le micro

`MENU-REASONIX.bat` → option 2 (ou `MENU-REASONIX.bat mic`). Le module copie `voice-input.js` dans `dist\` et ajoute un `<script>` dans `index.html` ; la sauvegarde de `index.html` est vérifiée par empreinte avant toute écriture.

## Ce qui est traduit

- Toute l'interface : menus, sous-menus, réglages, infobulles, messages d'erreur, pages de la 2.47 à la 2.52 (historique paginé, compaction du contexte, cartes de fichiers, mise en veille, Wallpaper Engine, raccourcis clavier, facturation).
- Les descriptions des outils intégrés affichées dans les réglages et les cartes d'appel.
- Les chaînes natives : démarrage, menu contextuel, menu du tray, plantages, ancienne version.

## Ce qui ne l'est pas

| Élément | Pourquoi |
|---|---|
| Le noyau Go (CLI, TUI) | catalogue compilé dans le binaire, non modifiable sans reconstruire Go |
| Les notifications système | passent par le noyau, désactivées par défaut |
| Les réponses du modèle | elles suivent la langue de tes messages, pas ce réglage |
| Les mots-clés de recherche des réglages | chaînes des tableaux `keywords:[…]` : jamais affichées, donc non traduites |
| Les noms propres | Reasonix, DeepSeek, GitHub, Wallpaper Engine, Discord, WeChat… |

## Restauration

Les originaux sont dans `backups\`, nommés `<horodatage>__<type>__<fichier>`.
Recopie le fichier voulu à sa place :

| Sauvegarde | Destination |
|---|---|
| `*__i18n__i18n-*.js` | `…\resources\frontend-next\dist\assets\` |
| `*__settings__Settings-*.js` | idem |
| `*__labels__*.js` | idem |
| `*__index__index.html` | `…\resources\frontend-next\dist\` |
| `*__app.asar` | `…\resources\app.asar` |

Restauration automatique du dernier original de chaque fichier :

```text
py tools\patch252.py --restore
```

## Après une mise à jour de Reasonix

Les bundles changent de nom : relance simplement `Francisation_2.52.bat`. Le script retrouve les nouveaux fichiers et les patche. Si un motif a changé, il s'arrête en le disant — il ne patch jamais à moitié. Les chaînes ajoutées par la nouvelle version se traduisent en complétant `dict\parts\` puis en relançant :

```text
node tools\extract252.js     # nouveau catalogue (clés chinoises -> anglais)
node tools\diff252.js        # écart avec le dictionnaire courant
node tools\build_fr252.js    # fusion + contrôles (couverture, placeholders, chinois)
```

## Contenu du paquet

```text
config.bat                    variables (installation, temporaire, python, node)
Francisation_2.52.bat         application en deux étapes
MENU-REASONIX.bat             menu unifié (français / micro / les deux)
tools\patch252.py             interface web (i18n, Settings, index.html, libellés)
tools\patch_asar252.py        chaînes natives d'app.asar
tools\asar_patches.json       motifs natifs (inchangés depuis la 2.49)
tools\extract252.js           extraction du catalogue du build installé
tools\diff252.js              écart catalogue / dictionnaire
tools\build_fr252.js          fusion des traductions + contrôles bloquants
tools\verify252.js            contrôle d'exécution : chaque clé rend du français
tools\audit252.js             audit du dictionnaire (chinois, restes anglais)
tools\audit_keys.js           clés utilisées par les bundles mais absentes du dictionnaire
tools\list_english.js         liste des entrées restées en anglais
dict\fr_dict_252.json         dictionnaire courant (5 221 entrées)
dict\fr_dict_249.json         dictionnaire livré en 2.49 (5 047 entrées)
dict\en_dict_252.json         catalogue anglais extrait du build 2.52
dict\parts\tr_252.json        les 174 chaînes neuves, indexées
dict\parts\ov_252.json        les 9 corrections d'entrées anglaises
backups\                      originaux des fichiers remplacés
old\                          archives écartées
menage-a-decider\             restes des builds précédents, à supprimer sur ton ordre
Reasonix-Voice-Input-publish\ module micro
```
