# Reasonix-FR-2.52

Pack de francisation + micro pour **Reasonix Studio 2.52** installé dans `J:\Reasonix Studio`.

| Fichier | Rôle |
|---|---|
| `Francisation_2.52.bat` | applique interface + chaînes natives (Studio fermé) |
| `MENU-REASONIX.bat` | menu : francisation, micro, ou les deux |
| `config.bat` | chemins et variables (seul fichier à modifier) |
| `LISEZ-MOI.md` | mode d'emploi complet, état vérifié, restauration |
| `tools\` | patch, extraction, fusion, contrôles |
| `dict\` | dictionnaires FR/EN et lots de traduction |
| `backups\` | originaux des fichiers remplacés (datés) |
| `menage-a-decider\` | restes des builds précédents, à supprimer sur ordre |

**Rien n'est supprimé** : tout ce qui sort de l'installation est déplacé dans `menage-a-decider\` et listé dans son `MANIFESTE.md`.

Contrôle rapide :

```text
py tools\patch252.py --dry-run
node tools\verify252.js
```
